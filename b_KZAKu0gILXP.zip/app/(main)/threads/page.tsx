'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { subscribeToThreads, createThread } from '@/lib/thread-service'
import { Thread } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Spinner } from '@/components/ui/spinner'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog'
import { Field, FieldLabel, FieldGroup, FieldDescription } from '@/components/ui/field'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Plus, MessageSquare, Lock, Clock } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { ja } from 'date-fns/locale'

export default function ThreadsPage() {
  const { user } = useAuth()
  const [threads, setThreads] = useState<Thread[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)

  const [newThread, setNewThread] = useState({
    title: '',
    hasPassword: false,
    password: '',
  })

  useEffect(() => {
    const unsubscribe = subscribeToThreads((data) => {
      setThreads(data)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const handleCreateThread = async () => {
    if (!user || !newThread.title.trim()) return

    setCreating(true)
    try {
      await createThread(
        newThread.title,
        user.id,
        user.username,
        newThread.hasPassword ? newThread.password : undefined
      )
      setNewThread({ title: '', hasPassword: false, password: '' })
      setDialogOpen(false)
    } catch (error) {
      console.error('Failed to create thread:', error)
    } finally {
      setCreating(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="h-8 w-8" />
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Thread-Page</h1>
          <p className="text-muted-foreground">
            数学のトピックについて議論しましょう
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              新規スレッド
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>新規スレッドを作成</DialogTitle>
              <DialogDescription>
                新しいディスカッションスレッドを作成します
              </DialogDescription>
            </DialogHeader>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="thread-title">タイトル</FieldLabel>
                <Input
                  id="thread-title"
                  placeholder="スレッドのタイトル"
                  value={newThread.title}
                  onChange={(e) => setNewThread({ ...newThread, title: e.target.value })}
                />
              </Field>
              <Field orientation="horizontal">
                <Checkbox
                  id="has-password"
                  checked={newThread.hasPassword}
                  onCheckedChange={(checked) =>
                    setNewThread({ ...newThread, hasPassword: checked === true })
                  }
                />
                <FieldLabel htmlFor="has-password">パスワードを設定する</FieldLabel>
              </Field>
              {newThread.hasPassword && (
                <Field>
                  <FieldLabel htmlFor="thread-password">パスワード</FieldLabel>
                  <Input
                    id="thread-password"
                    type="password"
                    placeholder="スレッドのパスワード"
                    value={newThread.password}
                    onChange={(e) => setNewThread({ ...newThread, password: e.target.value })}
                  />
                  <FieldDescription>
                    パスワードを知っているユーザーのみがスレッドに参加できます
                  </FieldDescription>
                </Field>
              )}
            </FieldGroup>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                キャンセル
              </Button>
              <Button onClick={handleCreateThread} disabled={creating || !newThread.title.trim()}>
                {creating ? <Spinner className="mr-2" /> : null}
                作成
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {threads.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">スレッドがありません</h3>
            <p className="text-muted-foreground text-center mb-4">
              最初のスレッドを作成して、ディスカッションを始めましょう
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              新規スレッドを作成
            </Button>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="space-y-3">
            {threads.map((thread) => (
              <Link key={thread.id} href={`/threads/${thread.id}`}>
                <Card className="hover:bg-accent/50 transition-colors cursor-pointer">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-base">{thread.title}</CardTitle>
                        {thread.hasPassword && (
                          <Lock className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {thread.messageCount} メッセージ
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center gap-2 text-xs">
                      <span>作成者: {thread.createdByUsername}</span>
                      <span>・</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(thread.updatedAt, { addSuffix: true, locale: ja })}
                      </span>
                    </CardDescription>
                  </CardHeader>
                  {thread.lastMessage && (
                    <CardContent className="pt-0">
                      <p className="text-sm text-muted-foreground truncate">
                        {thread.lastMessage}
                      </p>
                    </CardContent>
                  )}
                </Card>
              </Link>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  )
}
