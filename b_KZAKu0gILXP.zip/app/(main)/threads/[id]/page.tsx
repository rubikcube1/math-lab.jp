'use client'

import { useState, useEffect, useRef, use } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import {
  subscribeToMessages,
  addMessage,
  markMessageAsRead,
  editMessage,
  deleteMessage,
  verifyThreadPassword,
  deleteThread,
} from '@/lib/thread-service'
import { doc, getDoc, Timestamp } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { Message, Thread } from '@/lib/types'
import { MathRenderer } from '@/components/math-renderer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Spinner } from '@/components/ui/spinner'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Field, FieldLabel, FieldError } from '@/components/ui/field'
import {
  ArrowLeft,
  Send,
  MoreVertical,
  Edit2,
  Trash2,
  Lock,
  CheckCheck,
  Check,
} from 'lucide-react'
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'
import { ja } from 'date-fns/locale'

export default function ThreadDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const { user } = useAuth()
  const [thread, setThread] = useState<Thread | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [newMessage, setNewMessage] = useState('')
  const [passwordRequired, setPasswordRequired] = useState(false)
  const [password, setPassword] = useState('')
  const [passwordError, setPasswordError] = useState('')
  const [authenticated, setAuthenticated] = useState(false)
  const [editingMessage, setEditingMessage] = useState<Message | null>(null)
  const [editContent, setEditContent] = useState('')
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: 'message' | 'thread'; id: string } | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchThread = async () => {
      const threadDoc = await getDoc(doc(db, 'threads', resolvedParams.id))
      if (!threadDoc.exists()) {
        router.push('/threads')
        return
      }

      const data = threadDoc.data()
      const threadData: Thread = {
        id: threadDoc.id,
        title: data.title,
        createdBy: data.createdBy,
        createdByUsername: data.createdByUsername,
        createdAt: (data.createdAt as Timestamp)?.toDate() || new Date(),
        updatedAt: (data.updatedAt as Timestamp)?.toDate() || new Date(),
        hasPassword: data.hasPassword,
        messageCount: data.messageCount || 0,
        lastMessage: data.lastMessage,
        lastMessageAt: (data.lastMessageAt as Timestamp)?.toDate(),
      }
      setThread(threadData)

      if (threadData.hasPassword && threadData.createdBy !== user?.id) {
        setPasswordRequired(true)
      } else {
        setAuthenticated(true)
      }
      setLoading(false)
    }

    fetchThread()
  }, [resolvedParams.id, router, user?.id])

  useEffect(() => {
    if (!authenticated) return

    const unsubscribe = subscribeToMessages(resolvedParams.id, (data) => {
      setMessages(data)
      data.forEach((msg) => {
        if (user && !msg.readBy.includes(user.id)) {
          markMessageAsRead(msg.id, user.id)
        }
      })
    })

    return () => unsubscribe()
  }, [resolvedParams.id, authenticated, user])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handlePasswordSubmit = async () => {
    const isValid = await verifyThreadPassword(resolvedParams.id, password)
    if (isValid) {
      setAuthenticated(true)
      setPasswordRequired(false)
      setPasswordError('')
    } else {
      setPasswordError('パスワードが正しくありません')
    }
  }

  const handleSendMessage = async () => {
    if (!user || !newMessage.trim()) return

    setSending(true)
    try {
      await addMessage(resolvedParams.id, newMessage, user.id, user.username)
      setNewMessage('')
    } catch (error) {
      console.error('Failed to send message:', error)
    } finally {
      setSending(false)
    }
  }

  const handleEditMessage = async () => {
    if (!editingMessage || !editContent.trim()) return

    try {
      await editMessage(editingMessage.id, editContent)
      setEditingMessage(null)
      setEditContent('')
    } catch (error) {
      console.error('Failed to edit message:', error)
    }
  }

  const handleDeleteMessage = async (messageId: string) => {
    try {
      await deleteMessage(messageId, resolvedParams.id)
      setDeleteConfirm(null)
    } catch (error) {
      console.error('Failed to delete message:', error)
    }
  }

  const handleDeleteThread = async () => {
    try {
      await deleteThread(resolvedParams.id)
      router.push('/threads')
    } catch (error) {
      console.error('Failed to delete thread:', error)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="h-8 w-8" />
      </div>
    )
  }

  if (passwordRequired) {
    return (
      <div className="flex h-full items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-4">
          <div className="text-center">
            <Lock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">パスワードが必要です</h2>
            <p className="text-sm text-muted-foreground">
              このスレッドにアクセスするにはパスワードを入力してください
            </p>
          </div>
          <Field>
            <FieldLabel htmlFor="thread-password">パスワード</FieldLabel>
            <Input
              id="thread-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
            />
            {passwordError && <FieldError>{passwordError}</FieldError>}
          </Field>
          <div className="flex gap-2">
            <Button variant="outline" asChild className="flex-1">
              <Link href="/threads">戻る</Link>
            </Button>
            <Button onClick={handlePasswordSubmit} className="flex-1">
              認証
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/threads">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h1 className="font-semibold">{thread?.title}</h1>
            {thread?.hasPassword && <Lock className="h-4 w-4 text-muted-foreground" />}
          </div>
          <p className="text-xs text-muted-foreground">
            作成者: {thread?.createdByUsername}
          </p>
        </div>
        {(thread?.createdBy === user?.id || user?.isAdmin) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-destructive"
                onClick={() => setDeleteConfirm({ type: 'thread', id: resolvedParams.id })}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                スレッドを削除
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>まだメッセージはありません</p>
              <p className="text-sm">最初のメッセージを送信しましょう</p>
            </div>
          ) : (
            messages.map((message) => {
              const isOwnMessage = message.authorId === user?.id
              const allRead = message.readBy.length > 1

              return (
                <div
                  key={message.id}
                  className={`flex gap-3 ${isOwnMessage ? 'flex-row-reverse' : ''}`}
                >
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback className="text-xs">
                      {message.authorUsername.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`max-w-[70%] ${isOwnMessage ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="font-medium">{message.authorUsername}</span>
                      <span>
                        {formatDistanceToNow(message.createdAt, { addSuffix: true, locale: ja })}
                      </span>
                      {message.editedAt && <Badge variant="outline" className="text-xs">編集済み</Badge>}
                    </div>
                    <div
                      className={`rounded-lg px-3 py-2 ${
                        isOwnMessage
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <MathRenderer content={message.content} className="text-sm whitespace-pre-wrap break-words" />
                    </div>
                    <div className="flex items-center gap-1">
                      {isOwnMessage && (
                        <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                          {allRead ? (
                            <CheckCheck className="h-3 w-3 text-primary" />
                          ) : (
                            <Check className="h-3 w-3" />
                          )}
                        </span>
                      )}
                      {isOwnMessage && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <MoreVertical className="h-3 w-3" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => {
                                setEditingMessage(message)
                                setEditContent(message.content)
                              }}
                            >
                              <Edit2 className="h-4 w-4 mr-2" />
                              編集
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => setDeleteConfirm({ type: 'message', id: message.id })}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              削除
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </div>
                </div>
              )
            })
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="border-t p-4">
        <div className="flex gap-2">
          <Textarea
            placeholder="メッセージを入力... (数式は $...$ または $$...$$ で囲む)"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            className="min-h-[44px] max-h-32 resize-none"
            rows={1}
          />
          <Button onClick={handleSendMessage} disabled={sending || !newMessage.trim()}>
            {sending ? <Spinner /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          数式は LaTeX 形式で入力できます。インライン: $x^2$、ブロック: $$\int_0^1 x dx$$
        </p>
      </div>

      <Dialog open={!!editingMessage} onOpenChange={() => setEditingMessage(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>メッセージを編集</DialogTitle>
            <DialogDescription>メッセージの内容を編集します</DialogDescription>
          </DialogHeader>
          <Textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            className="min-h-[100px]"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingMessage(null)}>
              キャンセル
            </Button>
            <Button onClick={handleEditMessage}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {deleteConfirm?.type === 'thread' ? 'スレッドを削除' : 'メッセージを削除'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {deleteConfirm?.type === 'thread'
                ? 'このスレッドとすべてのメッセージが削除されます。この操作は取り消せません。'
                : 'このメッセージを削除しますか？この操作は取り消せません。'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deleteConfirm?.type === 'thread') {
                  handleDeleteThread()
                } else if (deleteConfirm?.id) {
                  handleDeleteMessage(deleteConfirm.id)
                }
              }}
            >
              削除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
