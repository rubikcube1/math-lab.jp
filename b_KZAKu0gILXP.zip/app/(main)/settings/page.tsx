"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FieldGroup, Field, FieldLabel } from "@/components/ui/field"
import { updatePassword } from "firebase/auth"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Spinner } from "@/components/ui/spinner"

export default function SettingsPage() {
  const { user, userData } = useAuth()
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [displayName, setDisplayName] = useState(userData?.displayName || "")
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const handlePasswordChange = async () => {
    if (!user) return
    if (newPassword !== confirmPassword) {
      setMessage({ type: "error", text: "パスワードが一致しません" })
      return
    }
    if (newPassword.length < 6) {
      setMessage({ type: "error", text: "パスワードは6文字以上必要です" })
      return
    }

    setLoading(true)
    try {
      await updatePassword(user, newPassword)
      setMessage({ type: "success", text: "パスワードを変更しました" })
      setNewPassword("")
      setConfirmPassword("")
    } catch (error) {
      setMessage({ type: "error", text: "パスワードの変更に失敗しました" })
    } finally {
      setLoading(false)
    }
  }

  const handleDisplayNameChange = async () => {
    if (!user) return
    if (!displayName.trim()) {
      setMessage({ type: "error", text: "表示名を入力してください" })
      return
    }

    setLoading(true)
    try {
      await updateDoc(doc(db, "users", user.uid), {
        displayName: displayName.trim(),
      })
      setMessage({ type: "success", text: "表示名を変更しました" })
    } catch (error) {
      setMessage({ type: "error", text: "表示名の変更に失敗しました" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container max-w-2xl py-8">
      <h1 className="text-2xl font-bold mb-6">設定</h1>

      {message && (
        <div
          className={`p-4 rounded-lg mb-6 ${
            message.type === "success"
              ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
              : "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>プロフィール</CardTitle>
            <CardDescription>表示名を変更できます</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field>
                <FieldLabel>ユーザー名</FieldLabel>
                <Input value={userData?.username || ""} disabled className="bg-muted" />
              </Field>
              <Field>
                <FieldLabel>表示名</FieldLabel>
                <Input
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="表示名を入力"
                />
              </Field>
              <Button onClick={handleDisplayNameChange} disabled={loading}>
                {loading ? <Spinner className="mr-2" /> : null}
                表示名を変更
              </Button>
            </FieldGroup>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>パスワード変更</CardTitle>
            <CardDescription>新しいパスワードを設定します</CardDescription>
          </CardHeader>
          <CardContent>
            <FieldGroup>
              <Field>
                <FieldLabel>新しいパスワード</FieldLabel>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="新しいパスワード"
                />
              </Field>
              <Field>
                <FieldLabel>パスワード確認</FieldLabel>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="パスワードを再入力"
                />
              </Field>
              <Button onClick={handlePasswordChange} disabled={loading}>
                {loading ? <Spinner className="mr-2" /> : null}
                パスワードを変更
              </Button>
            </FieldGroup>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>アカウント情報</CardTitle>
            <CardDescription>現在のアカウント状態</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">ステータス</span>
                <span className={userData?.isOnline ? "text-green-500" : "text-muted-foreground"}>
                  {userData?.isOnline ? "オンライン" : "オフライン"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">管理者</span>
                <span>{userData?.isAdmin ? "はい" : "いいえ"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">登録日</span>
                <span>
                  {userData?.createdAt
                    ? new Date(userData.createdAt.seconds * 1000).toLocaleDateString("ja-JP")
                    : "-"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
