'use client'

import { useAuth } from '@/lib/auth-context'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { MessageSquare, Bot, FileText, FlaskConical } from 'lucide-react'

export default function HomePage() {
  const { user } = useAuth()

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">
          ようこそ、{user?.username}さん
        </h1>
        <p className="text-muted-foreground mt-2">
          Math Lab - 数学を楽しむコミュニティ
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <MessageSquare className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Thread-Page</CardTitle>
                <CardDescription>スレッドで議論する</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              数学の問題やトピックについて、他のユーザーとリアルタイムで議論できます。
              数式もサポートしています。
            </p>
            <Button asChild className="w-full">
              <Link href="/threads">スレッドを見る</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow opacity-60">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Bot className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Luke-Bot</CardTitle>
                <CardDescription>AIアシスタント</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              数学の質問に答えてくれるAIチャットボット。
              複数のAIモデルを活用できます。
            </p>
            <Button disabled className="w-full">
              準備中
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow opacity-60">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>ライブラリ</CardTitle>
                <CardDescription>数学資料を共有</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              数学の問題集や解説、論文などを共有・閲覧できる
              デジタルライブラリです。
            </p>
            <Button disabled className="w-full">
              準備中
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-8">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <FlaskConical className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <CardTitle>Math Labについて</CardTitle>
              <CardDescription>数学を愛するコミュニティ</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Math Labは、数学を学び、共有し、楽しむためのコミュニティプラットフォームです。
            リアルタイムのスレッドディスカッション、AIアシスタント、ライブラリ機能を通じて、
            数学の理解を深め、知識を共有できます。LaTeX形式の数式表示にも対応しており、
            複雑な数式も美しく表現できます。
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
