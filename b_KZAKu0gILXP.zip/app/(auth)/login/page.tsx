'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Field, FieldLabel, FieldError, FieldGroup } from '@/components/ui/field'
import { Spinner } from '@/components/ui/spinner'
import { useAuth } from '@/lib/auth-context'
import { FlaskConical } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const { signIn, signUp } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [loginForm, setLoginForm] = useState({ username: '', password: '' })
  const [signupForm, setSignupForm] = useState({ username: '', password: '', confirmPassword: '', recognitionCode: '' })

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      await signIn(loginForm.username, loginForm.password)
      router.push('/')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'ログインに失敗しました')
    } finally {
      setLoading(false)
    }
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    if (signupForm.password !== signupForm.confirmPassword) {
      setError('パスワードが一致しません')
      setLoading(false)
      return
    }

    if (signupForm.password.length < 6) {
      setError('パスワードは6文字以上で入力してください')
      setLoading(false)
      return
    }

    try {
      await signUp(signupForm.username, signupForm.password, signupForm.recognitionCode)
      router.push('/')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'サインアップに失敗しました')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary">
            <FlaskConical className="h-6 w-6 text-primary-foreground" />
          </div>
          <CardTitle className="text-2xl">Math Lab</CardTitle>
          <CardDescription>数学コミュニティへようこそ</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">ログイン</TabsTrigger>
              <TabsTrigger value="signup">新規登録</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-4">
              <form onSubmit={handleLogin}>
                <FieldGroup>
                  <Field>
                    <FieldLabel htmlFor="login-username">ユーザー名</FieldLabel>
                    <Input
                      id="login-username"
                      type="text"
                      placeholder="username"
                      value={loginForm.username}
                      onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                      required
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="login-password">パスワード</FieldLabel>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="••••••••"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      required
                    />
                  </Field>

                  {error && <FieldError>{error}</FieldError>}

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? <Spinner className="mr-2" /> : null}
                    ログイン
                  </Button>
                </FieldGroup>
              </form>
            </TabsContent>

            <TabsContent value="signup" className="mt-4">
              <form onSubmit={handleSignup}>
                <FieldGroup>
                  <Field>
                    <FieldLabel htmlFor="signup-username">ユーザー名</FieldLabel>
                    <Input
                      id="signup-username"
                      type="text"
                      placeholder="10文字以下（日本語・英数字）"
                      value={signupForm.username}
                      onChange={(e) => setSignupForm({ ...signupForm, username: e.target.value })}
                      maxLength={10}
                      required
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="signup-password">パスワード</FieldLabel>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="6文字以上"
                      value={signupForm.password}
                      onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                      required
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="signup-confirm">パスワード確認</FieldLabel>
                    <Input
                      id="signup-confirm"
                      type="password"
                      placeholder="パスワードを再入力"
                      value={signupForm.confirmPassword}
                      onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })}
                      required
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="signup-code">共通認識コード</FieldLabel>
                    <Input
                      id="signup-code"
                      type="text"
                      placeholder="4桁の数字"
                      value={signupForm.recognitionCode}
                      onChange={(e) => setSignupForm({ ...signupForm, recognitionCode: e.target.value })}
                      maxLength={4}
                      required
                    />
                  </Field>

                  {error && <FieldError>{error}</FieldError>}

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? <Spinner className="mr-2" /> : null}
                    アカウント作成
                  </Button>
                </FieldGroup>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
