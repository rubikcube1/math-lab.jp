'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth'
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db } from './firebase'
import { User, RECOGNITION_CODE } from './types'

interface AuthContextType {
  user: User | null
  firebaseUser: FirebaseUser | null
  loading: boolean
  signIn: (username: string, password: string) => Promise<void>
  signUp: (username: string, password: string, recognitionCode: string) => Promise<void>
  signOut: () => Promise<void>
  updateActivity: (currentPage: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser)
      
      if (fbUser) {
        const userDoc = await getDoc(doc(db, 'users', fbUser.uid))
        if (userDoc.exists()) {
          const userData = userDoc.data()
          setUser({
            id: fbUser.uid,
            username: userData.username,
            displayName: userData.displayName || userData.username,
            createdAt: userData.createdAt?.toDate() || new Date(),
            lastActiveAt: userData.lastActiveAt?.toDate() || new Date(),
            isAdmin: userData.isAdmin || false,
            isOnline: true,
          })
          
          await updateDoc(doc(db, 'users', fbUser.uid), {
            isOnline: true,
            lastActiveAt: serverTimestamp(),
          })
        }
      } else {
        setUser(null)
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const validateUsername = (username: string): boolean => {
    if (username.length > 10) return false
    const regex = /^[a-zA-Z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]+$/
    return regex.test(username)
  }

  const signUp = async (username: string, password: string, recognitionCode: string) => {
    if (recognitionCode !== RECOGNITION_CODE) {
      throw new Error('共通認識コードが正しくありません')
    }

    if (!validateUsername(username)) {
      throw new Error('ユーザー名は10文字以下で、日本語・英数字のみ使用できます')
    }

    const email = `${username.toLowerCase()}@mathlab.local`
    
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      username,
      displayName: username,
      createdAt: serverTimestamp(),
      lastActiveAt: serverTimestamp(),
      isAdmin: false,
      isOnline: true,
    })
  }

  const signIn = async (username: string, password: string) => {
    const email = `${username.toLowerCase()}@mathlab.local`
    await signInWithEmailAndPassword(auth, email, password)
  }

  const signOut = async () => {
    if (firebaseUser) {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        isOnline: false,
        lastActiveAt: serverTimestamp(),
      })
    }
    await firebaseSignOut(auth)
  }

  const updateActivity = async (currentPage: string) => {
    if (firebaseUser) {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        lastActiveAt: serverTimestamp(),
        currentPage,
      })
    }
  }

  return (
    <AuthContext.Provider value={{ user, firebaseUser, loading, signIn, signUp, signOut, updateActivity }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
