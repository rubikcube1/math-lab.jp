import {
  collection,
  doc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  Timestamp,
} from 'firebase/firestore'
import { db } from './firebase'
import { User } from './types'

export interface UserWithActivity extends User {
  currentPage?: string
  totalMessages?: number
}

export async function getAllUsers(): Promise<UserWithActivity[]> {
  const q = query(collection(db, 'users'), orderBy('lastActiveAt', 'desc'))
  const snapshot = await getDocs(q)

  return snapshot.docs.map((doc) => ({
    id: doc.id,
    username: doc.data().username,
    displayName: doc.data().displayName || doc.data().username,
    createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
    lastActiveAt: (doc.data().lastActiveAt as Timestamp)?.toDate() || new Date(),
    isAdmin: doc.data().isAdmin || false,
    isOnline: doc.data().isOnline || false,
    currentPage: doc.data().currentPage,
  }))
}

export function subscribeToUsers(callback: (users: UserWithActivity[]) => void) {
  const q = query(collection(db, 'users'), orderBy('lastActiveAt', 'desc'))

  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map((doc) => ({
      id: doc.id,
      username: doc.data().username,
      displayName: doc.data().displayName || doc.data().username,
      createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
      lastActiveAt: (doc.data().lastActiveAt as Timestamp)?.toDate() || new Date(),
      isAdmin: doc.data().isAdmin || false,
      isOnline: doc.data().isOnline || false,
      currentPage: doc.data().currentPage,
    }))
    callback(users)
  })
}

export async function deleteUser(userId: string): Promise<void> {
  const messagesQuery = query(collection(db, 'messages'))
  const messagesSnapshot = await getDocs(messagesQuery)

  const userMessages = messagesSnapshot.docs.filter(
    (doc) => doc.data().authorId === userId
  )

  await Promise.all(userMessages.map((doc) => deleteDoc(doc.ref)))

  await deleteDoc(doc(db, 'users', userId))
}

export function formatDuration(start: Date, end: Date = new Date()): string {
  const diff = end.getTime() - start.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(minutes / 60)
  const days = Math.floor(hours / 24)

  if (days > 0) {
    return `${days}日前`
  } else if (hours > 0) {
    return `${hours}時間前`
  } else if (minutes > 0) {
    return `${minutes}分前`
  }
  return 'たった今'
}
