export interface User {
  id: string
  username: string
  displayName: string
  createdAt: Date
  lastActiveAt: Date
  isAdmin: boolean
  isOnline: boolean
}

export interface Thread {
  id: string
  title: string
  createdBy: string
  createdByUsername: string
  createdAt: Date
  updatedAt: Date
  hasPassword: boolean
  passwordHash?: string
  messageCount: number
  lastMessage?: string
  lastMessageAt?: Date
}

export interface Message {
  id: string
  threadId: string
  content: string
  authorId: string
  authorUsername: string
  createdAt: Date
  editedAt?: Date
  mentions: string[]
  readBy: string[]
}

export interface ActiveUser {
  id: string
  username: string
  lastActiveAt: Date
  currentPage: string
}

export const RECOGNITION_CODE = '6174'
