import {
  collection,
  doc,
  addDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Timestamp,
  limit,
} from 'firebase/firestore'
import { db } from './firebase'
import { Thread, Message } from './types'

function hashPassword(password: string): string {
  let hash = 0
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return hash.toString(16)
}

export async function createThread(
  title: string,
  userId: string,
  username: string,
  password?: string
): Promise<string> {
  const threadData: Record<string, unknown> = {
    title,
    createdBy: userId,
    createdByUsername: username,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    hasPassword: !!password,
    messageCount: 0,
  }

  if (password) {
    threadData.passwordHash = hashPassword(password)
  }

  const docRef = await addDoc(collection(db, 'threads'), threadData)
  return docRef.id
}

export async function verifyThreadPassword(threadId: string, password: string): Promise<boolean> {
  const threadDoc = await getDoc(doc(db, 'threads', threadId))
  if (!threadDoc.exists()) return false
  
  const thread = threadDoc.data()
  if (!thread.hasPassword) return true
  
  return thread.passwordHash === hashPassword(password)
}

export async function getThreads(): Promise<Thread[]> {
  const q = query(collection(db, 'threads'), orderBy('updatedAt', 'desc'))
  const snapshot = await getDocs(q)
  
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
    updatedAt: (doc.data().updatedAt as Timestamp)?.toDate() || new Date(),
    lastMessageAt: (doc.data().lastMessageAt as Timestamp)?.toDate(),
  })) as Thread[]
}

export function subscribeToThreads(callback: (threads: Thread[]) => void) {
  const q = query(collection(db, 'threads'), orderBy('updatedAt', 'desc'))
  
  return onSnapshot(q, (snapshot) => {
    const threads = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
      updatedAt: (doc.data().updatedAt as Timestamp)?.toDate() || new Date(),
      lastMessageAt: (doc.data().lastMessageAt as Timestamp)?.toDate(),
    })) as Thread[]
    callback(threads)
  })
}

export async function deleteThread(threadId: string): Promise<void> {
  const messagesQuery = query(collection(db, 'messages'), where('threadId', '==', threadId))
  const messagesSnapshot = await getDocs(messagesQuery)
  
  const deletePromises = messagesSnapshot.docs.map((doc) => deleteDoc(doc.ref))
  await Promise.all(deletePromises)
  
  await deleteDoc(doc(db, 'threads', threadId))
}

export async function addMessage(
  threadId: string,
  content: string,
  authorId: string,
  authorUsername: string
): Promise<string> {
  const mentions = extractMentions(content)
  
  const messageData = {
    threadId,
    content,
    authorId,
    authorUsername,
    createdAt: serverTimestamp(),
    mentions,
    readBy: [authorId],
  }

  const docRef = await addDoc(collection(db, 'messages'), messageData)
  
  const threadRef = doc(db, 'threads', threadId)
  const threadDoc = await getDoc(threadRef)
  const currentCount = threadDoc.data()?.messageCount || 0
  
  await updateDoc(threadRef, {
    updatedAt: serverTimestamp(),
    lastMessage: content.slice(0, 100),
    lastMessageAt: serverTimestamp(),
    messageCount: currentCount + 1,
  })

  return docRef.id
}

export function subscribeToMessages(threadId: string, callback: (messages: Message[]) => void) {
  const q = query(
    collection(db, 'messages'),
    where('threadId', '==', threadId),
    orderBy('createdAt', 'asc')
  )
  
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
      editedAt: (doc.data().editedAt as Timestamp)?.toDate(),
    })) as Message[]
    callback(messages)
  })
}

export async function markMessageAsRead(messageId: string, userId: string): Promise<void> {
  const messageRef = doc(db, 'messages', messageId)
  const messageDoc = await getDoc(messageRef)
  
  if (messageDoc.exists()) {
    const readBy = messageDoc.data().readBy || []
    if (!readBy.includes(userId)) {
      await updateDoc(messageRef, {
        readBy: [...readBy, userId],
      })
    }
  }
}

export async function editMessage(messageId: string, newContent: string): Promise<void> {
  const mentions = extractMentions(newContent)
  
  await updateDoc(doc(db, 'messages', messageId), {
    content: newContent,
    editedAt: serverTimestamp(),
    mentions,
  })
}

export async function deleteMessage(messageId: string, threadId: string): Promise<void> {
  await deleteDoc(doc(db, 'messages', messageId))
  
  const threadRef = doc(db, 'threads', threadId)
  const threadDoc = await getDoc(threadRef)
  const currentCount = threadDoc.data()?.messageCount || 0
  
  await updateDoc(threadRef, {
    messageCount: Math.max(0, currentCount - 1),
  })
}

function extractMentions(content: string): string[] {
  const mentionRegex = /@(\w+)/g
  const mentions: string[] = []
  let match
  
  while ((match = mentionRegex.exec(content)) !== null) {
    mentions.push(match[1])
  }
  
  return [...new Set(mentions)]
}

export async function getRecentMessages(threadId: string, count: number = 50): Promise<Message[]> {
  const q = query(
    collection(db, 'messages'),
    where('threadId', '==', threadId),
    orderBy('createdAt', 'desc'),
    limit(count)
  )
  
  const snapshot = await getDocs(q)
  
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: (doc.data().createdAt as Timestamp)?.toDate() || new Date(),
    editedAt: (doc.data().editedAt as Timestamp)?.toDate(),
  })).reverse() as Message[]
}
