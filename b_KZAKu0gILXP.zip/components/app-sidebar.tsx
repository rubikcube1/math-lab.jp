'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { collection, query, where, onSnapshot, Timestamp } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { useAuth } from '@/lib/auth-context'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from '@/components/ui/sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  FlaskConical,
  MessageSquare,
  Bot,
  FileText,
  Settings,
  LogOut,
  Users,
  Shield,
  ChevronDown,
} from 'lucide-react'
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible'

interface ActiveUser {
  id: string
  username: string
  lastActiveAt: Date
  currentPage?: string
}

const navItems = [
  { href: '/', label: 'ホーム', icon: FlaskConical },
  { href: '/threads', label: 'Thread-Page', icon: MessageSquare },
  { href: '/luke-bot', label: 'Luke-Bot', icon: Bot, disabled: true },
  { href: '/library', label: 'ライブラリ', icon: FileText, disabled: true },
]

export function AppSidebar() {
  const pathname = usePathname()
  const { user, signOut } = useAuth()
  const [activeUsers, setActiveUsers] = useState<ActiveUser[]>([])
  const [adminCode, setAdminCode] = useState('')
  const [showAdminDialog, setShowAdminDialog] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000)
    const q = query(
      collection(db, 'users'),
      where('isOnline', '==', true)
    )

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const users = snapshot.docs
        .map((doc) => ({
          id: doc.id,
          username: doc.data().username,
          lastActiveAt: (doc.data().lastActiveAt as Timestamp)?.toDate() || new Date(),
          currentPage: doc.data().currentPage,
        }))
        .filter((u) => u.lastActiveAt > fiveMinutesAgo)
      setActiveUsers(users)
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    if (user?.isAdmin) {
      setIsAdmin(true)
    }
  }, [user])

  const handleAdminLogin = () => {
    if (adminCode === 'ADMIN_SECRET_CODE') {
      setIsAdmin(true)
      setShowAdminDialog(false)
    }
  }

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-1">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
            <FlaskConical className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-semibold">Math Lab</span>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>ナビゲーション</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild={!item.disabled}
                    isActive={pathname === item.href}
                    tooltip={item.label}
                    disabled={item.disabled}
                  >
                    {item.disabled ? (
                      <span className="opacity-50">
                        <item.icon className="h-4 w-4" />
                        <span>{item.label}</span>
                        <Badge variant="outline" className="ml-auto text-xs">
                          準備中
                        </Badge>
                      </span>
                    ) : (
                      <Link href={item.href}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.label}</span>
                      </Link>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <Collapsible defaultOpen>
            <CollapsibleTrigger asChild>
              <SidebarGroupLabel className="cursor-pointer hover:bg-sidebar-accent rounded-md">
                <Users className="h-4 w-4 mr-2" />
                アクティブユーザー ({activeUsers.length})
                <ChevronDown className="ml-auto h-4 w-4" />
              </SidebarGroupLabel>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <SidebarGroupContent>
                <div className="space-y-1 px-2">
                  {activeUsers.length === 0 ? (
                    <p className="text-xs text-muted-foreground py-2">
                      現在アクティブなユーザーはいません
                    </p>
                  ) : (
                    activeUsers.map((activeUser) => (
                      <div
                        key={activeUser.id}
                        className="flex items-center gap-2 py-1"
                      >
                        <div className="relative">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">
                              {activeUser.username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-500 border-2 border-sidebar" />
                        </div>
                        <span className="text-sm truncate">{activeUser.username}</span>
                      </div>
                    ))
                  )}
                </div>
              </SidebarGroupContent>
            </CollapsibleContent>
          </Collapsible>
        </SidebarGroup>

        {isAdmin && (
          <>
            <SidebarSeparator />
            <SidebarGroup>
              <SidebarGroupLabel>
                <Shield className="h-4 w-4 mr-2" />
                管理者
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild>
                      <Link href="/admin">
                        <Settings className="h-4 w-4" />
                        <span>管理パネル</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        {!isAdmin && (
          <Dialog open={showAdminDialog} onOpenChange={setShowAdminDialog}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="w-full justify-start">
                <Shield className="h-4 w-4 mr-2" />
                管理者ログイン
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>管理者認証</DialogTitle>
                <DialogDescription>
                  管理者コードを入力してください
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  type="password"
                  placeholder="管理者コード"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                />
                <Button onClick={handleAdminLogin} className="w-full">
                  認証
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {user && (
          <div className="flex items-center gap-2 p-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback>
                {user.username.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 truncate">
              <p className="text-sm font-medium truncate">{user.username}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => signOut()}
              className="h-8 w-8"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  )
}
