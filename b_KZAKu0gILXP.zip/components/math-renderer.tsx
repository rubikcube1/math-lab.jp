'use client'

import { useMemo } from 'react'
import katex from 'katex'
import 'katex/dist/katex.min.css'

interface MathRendererProps {
  content: string
  className?: string
}

export function MathRenderer({ content, className = '' }: MathRendererProps) {
  const renderedContent = useMemo(() => {
    const parts: { type: 'text' | 'math'; content: string; display: boolean }[] = []
    let remaining = content

    const displayRegex = /\$\$([\s\S]*?)\$\$/g
    const inlineRegex = /\$((?!\$)[\s\S]*?)\$/g

    let lastIndex = 0
    const allMatches: { index: number; end: number; math: string; display: boolean }[] = []

    let match
    while ((match = displayRegex.exec(content)) !== null) {
      allMatches.push({
        index: match.index,
        end: match.index + match[0].length,
        math: match[1],
        display: true,
      })
    }

    while ((match = inlineRegex.exec(content)) !== null) {
      const overlaps = allMatches.some(
        (m) => match!.index >= m.index && match!.index < m.end
      )
      if (!overlaps) {
        allMatches.push({
          index: match.index,
          end: match.index + match[0].length,
          math: match[1],
          display: false,
        })
      }
    }

    allMatches.sort((a, b) => a.index - b.index)

    for (const m of allMatches) {
      if (m.index > lastIndex) {
        parts.push({
          type: 'text',
          content: remaining.slice(lastIndex, m.index),
          display: false,
        })
      }
      parts.push({
        type: 'math',
        content: m.math,
        display: m.display,
      })
      lastIndex = m.end
    }

    if (lastIndex < remaining.length) {
      parts.push({
        type: 'text',
        content: remaining.slice(lastIndex),
        display: false,
      })
    }

    return parts.map((part, i) => {
      if (part.type === 'text') {
        return <span key={i}>{part.content}</span>
      }

      try {
        const html = katex.renderToString(part.content, {
          throwOnError: false,
          displayMode: part.display,
        })
        return (
          <span
            key={i}
            className={part.display ? 'block my-2 text-center' : 'inline'}
            dangerouslySetInnerHTML={{ __html: html }}
          />
        )
      } catch {
        return <span key={i} className="text-destructive">{part.content}</span>
      }
    })
  }, [content])

  return <span className={className}>{renderedContent}</span>
}
